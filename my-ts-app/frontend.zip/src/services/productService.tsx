import axios from "axios";

const API_BASE_URL = "http://localhost:4000";

export const getproduct = async () => {
  const response = await axios.get(`${API_BASE_URL}/products`);
  return response.data;
};

// export const getcustomerById = async (id) => {
//   const response = await axios.get(`${API_BASE_URL}/products/${id}`);
//   return response.data;
// };