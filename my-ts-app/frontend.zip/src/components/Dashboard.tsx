import { useState } from "react";
import { Sidebar } from "./dashboard/Sidebar";
import { Overview } from "./dashboard/Overview";
import { SalesPerformance } from "./dashboard/SalesPerformance";
import { InventoryManagement } from "./dashboard/InventoryManagement";
import { CustomerInsights } from "./dashboard/CustomerInsights";
// import { EmployeePerformance } from "./dashboard/EmployeePerformance";
import { ProductAnalysis } from "./dashboard/ProductsAnalysis";

export type DashboardSection = 
  | 'overview' 
  | 'sales' 
  | 'inventory' 
  | 'customers' 
  | 'employees' 
  | 'products';

export const Dashboard = () => {
  const [activeSection, setActiveSection] = useState<DashboardSection>('overview');
  const renderContent = () => {
    switch (activeSection) {
      case 'overview':
        return <Overview />;
      case 'sales':
        return <SalesPerformance 
        />;
      case 'inventory':
        return <InventoryManagement 
        />;
      case 'customers':
        return <CustomerInsights />;
    //   case 'employees':
    //     return <EmployeePerformance />;
      case 'products':
        return <ProductAnalysis />;
      default:
        return <Overview />;
    }
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar 
        activeSection={activeSection} 
        onSectionChange={setActiveSection} 
      />
      <main className="flex-1 p-6">
        {renderContent()}
      </main>
    </div>
  );
};