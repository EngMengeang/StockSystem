import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, UserCheck, TrendingUp, Edit, Settings } from "lucide-react";
import { useState, useEffect } from "react";

// table
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button";

// api
import { getcustomer } from "@/services/customerService";

export const CustomerInsights = () => {
  const [customers, setCustomers] = useState([]);

  useEffect(() => {
    fetchCustomer();
  }, []);

  const fetchCustomer = async () => {
      try {
              const data = await getcustomer();
              setCustomers(data);
          } catch (error) {
              console.error("Error fetching stations:", error);
          }
      };
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight text-foreground">Customer Insights</h2>
        <p className="text-muted-foreground">
          Understand customer behavior and loyalty patterns
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Customers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,247</div>
            <p className="text-xs text-muted-foreground">
              Registered customers
            </p>
          </CardContent>
        </Card>

        {/* <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Repeat Customers</CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">68%</div>
            <p className="text-xs text-muted-foreground">
              Customer retention rate
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. Spend</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$42.18</div>
            <p className="text-xs text-muted-foreground">
              Per customer visit
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Top Customers by Spending</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">John Smith</p>
                  <p className="text-xs text-muted-foreground">john@email.com</p>
                  <p className="text-xs text-muted-foreground">Vehicle: Sedan | ABC-123</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold">$1,234.56</p>
                  <p className="text-xs text-muted-foreground">Total spent</p>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Sarah Johnson</p>
                  <p className="text-xs text-muted-foreground">sarah@email.com</p>
                  <p className="text-xs text-muted-foreground">Vehicle: SUV | XYZ-789</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold">$987.43</p>
                  <p className="text-xs text-muted-foreground">Total spent</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card> */}

        <Card>
          <CardHeader>
            <CardTitle>Customer Visit Frequency</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Customer frequency chart will be displayed here</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Customers</CardTitle>
        </CardHeader>
        <CardContent className="overflow-y-auto max-h-90">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Phone number</TableHead>
                <TableHead>Address</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Vehicletypename</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {customers.length > 0 ? (
                customers.map((item) => (
                  <TableRow key={item.customerid}>
                    <TableCell>{item.customername}</TableCell>
                    <TableCell>{item.phonenumber}</TableCell>
                    <TableCell>{item.address}</TableCell>
                    <TableCell>{item.email}</TableCell>
                    <TableCell>{item.vehicletypename}</TableCell>
                    <TableCell className="space-x-2 text-right">
                      <Button variant="outline" size="icon">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="icon">
                        <Settings className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={4} className="text-center">
                    No products found
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};