import { 
  BarChart3, 
  TrendingUp, 
  Package, 
  Users, 
  UserCheck, 
  ShoppingCart,
  Fuel
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { DashboardSection } from "../Dashboard";

interface SidebarProps {
  activeSection: DashboardSection;
  onSectionChange: (section: DashboardSection) => void;
}

const menuItems = [
  { id: 'overview' as const, label: 'Overview', icon: BarChart3 },
  { id: 'sales' as const, label: 'Sales Performance', icon: TrendingUp },
  { id: 'inventory' as const, label: 'Inventory Management', icon: Package },
  { id: 'customers' as const, label: 'Customer Insights', icon: Users },
  // { id: 'employees' as const, label: 'Employee Performance', icon: UserCheck },
  { id: 'products' as const, label: 'Product Analysis', icon: ShoppingCart },
];

export const Sidebar = ({ activeSection, onSectionChange }: SidebarProps) => {
  return (
    <div className="w-64 bg-card border-r border-border">
      <div className="p-6">
        <div className="flex items-center gap-2 mb-8">
          <Fuel className="h-8 w-8 text-primary" />
          <h1 className="text-xl font-bold text-foreground">Station Dashboard</h1>
        </div>
        
        <nav className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onSectionChange(item.id)}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors",
                  isActive 
                    ? "bg-primary text-primary-foreground" 
                    : "text-muted-foreground hover:text-foreground hover:bg-accent"
                )}
              >
                <Icon className="h-5 w-5" />
                <span className="font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
};