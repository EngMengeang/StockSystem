import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState, useEffect } from "react";
import { AlertTriangle, Package, Fuel, Edit, Settings  } from "lucide-react";
// select
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
// table
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button";
// api
import { getgasstation } from "@/services/stationService";
import { getinvoice } from "@/services/invoiceService";

export const SalesPerformance = () => {
      const [stations, setStations] = useState([]);
      const [selectedStation, setSelectedStation] = useState();
      const [invoice, setInvoice] = useState([]);

      useEffect(() => {
        fetchStations();
    }, []);

      useEffect(() => {
        console.log("Selected station:", selectedStation);
          fetchInvoice();
      }, [selectedStation]);

    useEffect(() => {
      console.log("Invoice state updated:", invoice.map(item => item));
    }, [invoice]);

    const fetchStations = async () => {
      try {
              const data = await getgasstation();
              setStations(data);
          } catch (error) {
              console.error("Error fetching stations:", error);
        }
    }

    const fetchInvoice = async () => {
      try {
              const data = await getinvoice(selectedStation);
              setInvoice(data);
          } catch (error) {
              console.error("Error fetching stations:", error);
        }
    }
  return (
    <div className="space-y-6">
      <div className="flex justify-between">
        <div>
            <h2 className="text-3xl font-bold tracking-tight text-foreground">Sales Performance</h2>
            <p className="text-muted-foreground">
            Analyze sales trends and product performance
            </p>
        </div>
        <div className="flex items-center space-x-4">
            <Label htmlFor="role">Station</Label>
            <Select value={selectedStation} onValueChange={(value) => setSelectedStation(value)} >
                <SelectTrigger>
                    <SelectValue placeholder="Select your role" />
                </SelectTrigger>
                <SelectContent className="w-48 max-h-60 rounded-md background-white shadow-lg">
                    {
                        stations.map((station) => (
                            <SelectItem key={station.gasstationid} value={station.gasstationid}>
                                {station.gasstationname}
                            </SelectItem>
                        ))
                    }
                </SelectContent>
            </Select>
        </div>
      </div>
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
          <TabsTrigger value="products">Top Products</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Daily Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$2,345.67</div>
                <p className="text-xs text-muted-foreground">Today's sales</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Average Transaction</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$43.12</div>
                <p className="text-xs text-muted-foreground">Per transaction</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Sales Target</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">78%</div>
                <p className="text-xs text-muted-foreground">Monthly progress</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="trends" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Sales Trends (Last 30 Days)</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">Revenue trend chart will be displayed here</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="products" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Top Selling Products</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Regular Gasoline</p>
                    <p className="text-xs text-muted-foreground">Fuel | $3.49/gallon</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold">$5,234.56</p>
                    <p className="text-xs text-muted-foreground">1,500 gallons sold</p>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Coffee</p>
                    <p className="text-xs text-muted-foreground">Beverage | $2.99/cup</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold">$897.43</p>
                    <p className="text-xs text-muted-foreground">300 cups sold</p>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Snacks Combo</p>
                    <p className="text-xs text-muted-foreground">Food | $4.99/pack</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold">$649.87</p>
                    <p className="text-xs text-muted-foreground">130 packs sold</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      {/* table */}
      <Card>
        <CardHeader>
          <CardTitle>Sales Invoices</CardTitle>
        </CardHeader>
        <CardContent className="overflow-y-auto max-h-80">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Customer</TableHead>
                <TableHead>Product</TableHead>
                <TableHead>Gasstation</TableHead>
                <TableHead>Sold</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Total Price</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {invoice.length > 0 ? (
                invoice.map((item) => (
                  <TableRow key={item.invoiceid}>
                    <TableCell>{item.customername}</TableCell>
                    <TableCell>{item.productname}</TableCell>
                    <TableCell>{item.gasstationname}</TableCell>
                    <TableCell>{item.quantitysold}</TableCell>
                    <TableCell>{item.sellingprice}</TableCell>
                    <TableCell>{item.total_price}</TableCell>
                    <TableCell className="space-x-2 text-right">
                      <Button variant="outline" size="icon">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="icon">
                        <Settings className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={4} className="text-center">
                    No products found
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};