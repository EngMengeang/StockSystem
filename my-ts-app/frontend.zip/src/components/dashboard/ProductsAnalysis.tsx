import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button";
import { Package, TrendingUp, AlertCircle, Edit, Settings } from "lucide-react";
import { useState, useEffect } from "react";
import { getproduct } from "@/services/productService";

export const ProductAnalysis = () => {
  const [products, setProduct] = useState([]);

  useEffect(() => {
    fetchProduct();
  }, []);
  useEffect(() => {
    console.log("Products state updated:", products.map(product => product.productname));
  }, [products]);

  const fetchProduct= async () => {
      try {
        const data = await getproduct(); 
        setProduct(data);
      } catch (error) {
        console.error("Error fetching customers:", error);
      }
  };
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight text-foreground">Product Analysis</h2>
        <p className="text-muted-foreground">
          Detailed insights into product performance and inventory
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Product Categories</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{products.length}</div>
            <p className="text-xs text-muted-foreground">
              Active categories
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Best Selling</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Snacks</div>
            <p className="text-xs text-muted-foreground">
              Top category by volume
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Stock Alerts</CardTitle>
            <AlertCircle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5</div>
            <p className="text-xs text-muted-foreground">
              Products need restocking
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="performance" className="space-y-4">
        <TabsList>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="stock">Stock Levels</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
        </TabsList>

        <TabsContent value="performance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Products</CardTitle>
            </CardHeader>
            <CardContent className="overflow-y-auto max-h-85">
              <Table>
                <TableHeader>
                    <TableRow>
                      <TableHead>Product Name</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Stock</TableHead>
                      <TableHead>Type</TableHead>
                      {/* <TableHead>Status</TableHead> */}
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                <TableBody>
                  { products.length > 0 ? products.map((product) => (
                  <TableRow key={product.productid}>
                    <TableCell className="font-medium">{product.productname}</TableCell>
                    <TableCell>${product.unitprice}</TableCell>
                    <TableCell>{product.stockquantity}</TableCell>
                    <TableCell>{product.producttype}</TableCell>
                    {/* <TableCell>
                      <Badge variant={product.lowStock ? "destructive" : "default"}>
                        {product.lowStock ? "Low Stock" : "In Stock"}
                      </Badge>
                    </TableCell> */}
                    <TableCell>
                      <div className="space-x-2 text-right">
                        <Button variant="ghost" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Settings className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>)
                  ) : (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center">
                        No products found
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>    
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="stock" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Current Stock Levels</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Motor Oil 5W-30</span>
                  <Badge variant="destructive">Low (3 units)</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Energy Drinks</span>
                  <Badge variant="destructive">Low (12 units)</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Candy Bars</span>
                  <Badge variant="secondary">Good (156 units)</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Coffee</span>
                  <Badge variant="secondary">Good (89 units)</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="categories" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Sales by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">Category performance chart will be displayed here</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};